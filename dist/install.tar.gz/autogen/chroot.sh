#!/bin/sh
# WARNING! this file has been generated automatically
set -x

# base system

source /etc/profile || exit 1
# sync portage and update the system
emerge-webrsync || exit 1
eselect profile set default/linux/amd64/17.1 || exit 1
emerge -uDN --with-bdeps=y @world || exit 1
# timezone
echo Europe/Zurich > /etc/timezone || exit 1
emerge --config sys-libs/timezone-data || exit 1
env-update || exit 1
source /etc/profile || exit 1

# kernel

# install kernel
emerge sys-kernel/installkernel-gentoo || exit 1
emerge sys-kernel/gentoo-kernel-bin || exit 1

# system config

# set hostname
echo "# Set the hostname variable to the selected host name" > /etc/conf.d/hostname || exit 1
echo "hostname=\"frost\"" >> /etc/conf.d/hostname || exit 1
# network
emerge net-misc/dhcpcd || exit 1
rc-update add dhcpcd default || exit 1
root #rc-service dhcpcd start || exit 1
# IMPORTANT: root password empty by default
passwd -d root || exit 1

# system tools

# logger
emerge app-admin/sysklogd || exit 1
rc-update add sysklogd default || exit 1
# crond
emerge sys-process/cronie || exit 1
rc-update add cronie default || exit 1
# additional utils
emerge sys-apps/mlocate || exit 1

# bootloader

# install the bootloader
emerge sys-boot/grub || exit 1
grub-install /dev/sda || exit 1
grub-mkconfig -o /boot/grub/grub.cfg || exit 1

# custom post-install

# base tools
emerge app-portage/eix sys-process/htop app-admin/sudo
eix-update

# # display manager
# emerge x11-misc/sddm
# rc-update add display-manager default

# # install plasma and base desktop tools
# emerge kde-plasma/plasma-meta
# emerge kde-apps/kdecore-meta kde-apps/kdeadmin-meta kde-apps/kdeutils-meta

# # some additional stuff
# emerge app-misc/neofetch
