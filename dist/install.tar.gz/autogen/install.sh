#!/bin/sh
# WARNING! this file has been generated automatically
set -x

# network

# synchronize time using NTP
ntpd -g -q || exit 1

# disks and partitions

# partition the drive
cat disks.sfdisk | sfdisk /dev/sda || exit 1
# format the partitions
mkfs.ext4 /dev/sda2 || exit 1
mkfs.ext4 /dev/sda3 || exit 1
# mount the partitions
mkdir -p /mnt/gentoo/ || exit 1
mount /dev/sda3 /mnt/gentoo/ || exit 1
mkdir -p /mnt/gentoo/boot || exit 1
mount /dev/sda2 /mnt/gentoo/boot || exit 1

# stage3

# download stage3
STAGE3_PATH=$(curl -s https://mirror.init7.net/gentoo//releases/amd64/autobuilds/latest-stage3-amd64-openrc.txt | tail -n 1 | cut -d ' ' -f 1) || exit 1
STAGE3_URL=https://mirror.init7.net/gentoo//releases/amd64/autobuilds/$STAGE3_PATH || exit 1
wget $STAGE3_URL || exit 1
# untar stage3
tar xpvf stage3-*.tar.xz --xattrs-include='*.*' --numeric-owner --directory /mnt/gentoo || exit 1

# copy config

# append the proper drive config to the fstab file
cat fstab.txt >> /mnt/gentoo/etc/fstab || exit 1
# rsync the etc directory to the chroot
rsync --archive --ignore-times etc/ /mnt/gentoo/etc/ || exit 1

# base system

# portage config
mkdir -p /mnt/gentoo/etc/portage/repos.conf || exit 1
cp /mnt/gentoo/usr/share/portage/config/repos.conf /mnt/gentoo/etc/portage/repos.conf/gentoo.conf || exit 1
# chroot
cp --dereference /etc/resolv.conf /mnt/gentoo/etc || exit 1
mount --types proc /proc /mnt/gentoo/proc || exit 1
mount --rbind /sys /mnt/gentoo/sys || exit 1
mount --rbind /dev /mnt/gentoo/dev || exit 1
mount --bind /run /mnt/gentoo/run || exit 1
# the install continues in chroot.sh
chmod +x chroot.sh || exit 1
cp chroot.sh /mnt/gentoo/chroot.sh || exit 1
chroot /mnt/gentoo ./chroot.sh || exit 1

# finalize

# unmount all filesystems
umount -l /mnt/gentoo/dev{/shm,/pts,} || exit 1
umount -R /mnt/gentoo || exit 1
# display a nice message to the user
cat done.txt || exit 1
