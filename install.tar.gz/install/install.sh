#!/bin/sh
# WARNING! this file has been generated automatically
set -x

# disks and partitions

# partition the drive
cat disks.sfdisk | sfdisk /dev/sda || exit 1
# format the partitions
mkfs.ext2 /dev/sda2 || exit 1
mkfs.ext4 /dev/sda3 || exit 1
# mount the partitions
mkdir -p /mnt/gentoo/ || exit 1
mount /dev/sda3 /mnt/gentoo/ || exit 1
mkdir -p /mnt/gentoo/boot || exit 1
mount /dev/sda2 /mnt/gentoo/boot || exit 1

# stage3

# download stage3
STAGE3_PATH=$(curl -s https://mirror.init7.net/gentoo/releases/amd64/autobuilds/latest-stage3-amd64-openrc.txt | tail -n 1 | cut -d ' ' -f 1) || exit 1
STAGE3_URL=https://mirror.init7.net/gentoo/releases/amd64/autobuilds/$STAGE3_PATH || exit 1
wget $STAGE3_URL || exit 1
# untar stage3
tar xpvf stage3-*.tar.xz --xattrs-include='*.*' --numeric-owner --directory /mnt/gentoo || exit 1

# base system

# portage config
cp make.conf /mnt/gentoo/etc/portage/make.conf || exit 1
mkdir -p /mnt/gentoo/etc/portage/repos.conf || exit 1
cp /mnt/gentoo/usr/share/portage/config/repos.conf /mnt/gentoo/etc/portage/repos.conf/gentoo.conf || exit 1
# chroot
cp --dereference /etc/resolv.conf /mnt/gentoo/etc || exit 1
mount --types proc /proc /mnt/gentoo/proc || exit 1
mount --rbind /sys /mnt/gentoo/sys || exit 1
mount --rbind /dev /mnt/gentoo/dev || exit 1
mount --bind /run /mnt/gentoo/run || exit 1
# the install continues in chroot.sh
chmod +x chroot.sh || exit 1
cp chroot.sh /mnt/gentoo/chroot.sh || exit 1
chroot /mnt/gentoo ./chroot.sh || exit 1
